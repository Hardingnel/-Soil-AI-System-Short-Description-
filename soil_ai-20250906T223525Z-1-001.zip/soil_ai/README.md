---
title: Soil AI
emoji: 🌍
colorFrom: green
colorTo: blue
sdk: gradio
sdk_version: 4.44.0
app_file: app/app.py
pinned: false
---

# Soil AI

Multi-tab geotechnical tool for PSD (Sieve), Plasticity (LL/PL), CBR (CSV or manual), plus Summary & Export.
