
from __future__ import annotations
from typing import Iterable, List, Tuple, Dict, Any
import math

def _is_num(x: Any) -> bool:
    try:
        float(x)
        return True
    except Exception:
        return False

def _as_pairs(sizes_mm: Iterable[float] | None = None,
              passing_pct: Iterable[float] | None = None,
              pairs: Iterable[Tuple[float, float]] | None = None) -> List[Tuple[float, float]]:
    if pairs is not None:
        data = [(float(s), float(p)) for (s, p) in pairs if _is_num(s) and _is_num(p)]
    elif sizes_mm is not None and passing_pct is not None:
        data = [(float(s), float(p)) for s, p in zip(sizes_mm, passing_pct) if _is_num(s) and _is_num(p)]
    else:
        raise ValueError("Provide either (sizes_mm & passing_pct) or pairs=[(size, passing), ...].")
    data = [(s, p) for (s, p) in data if s > 0 and 0 <= p <= 100]
    if not data:
        raise ValueError("No valid PSD pairs after cleaning.")
    return data

def _ensure_monotonic(pairs: List[Tuple[float, float]]) -> List[Tuple[float, float]]:
    pairs = sorted(pairs, key=lambda t: t[0], reverse=True)
    fixed: List[Tuple[float, float]] = []
    last = -math.inf
    for s, p in pairs:
        if p < last:
            p = last
        last = p
        fixed.append((s, p))
    return fixed

def _interp_dx(pairs: List[Tuple[float, float]], target_pct: float) -> float:
    if len(pairs) < 2:
        return float("nan")
    for (s1, y1), (s2, y2) in zip(pairs[:-1], pairs[1:]):
        if (y1 <= target_pct <= y2) or (y2 <= target_pct <= y1):
            if s1 <= 0 or s2 <= 0:
                return float("nan")
            x1, x2 = math.log10(s1), math.log10(s2)
            if y2 == y1:
                x = x1
            else:
                x = x1 + (x2 - x1) * (target_pct - y1) / (y2 - y1)
            return 10 ** x
    return float("nan")

def compute_d_values(sizes_mm=None, passing_pct=None, pairs=None) -> Dict[str, float]:
    raw = _as_pairs(sizes_mm, passing_pct, pairs)
    pairs_mono = _ensure_monotonic(raw)
    D10 = _interp_dx(pairs_mono, 10.0)
    D30 = _interp_dx(pairs_mono, 30.0)
    D60 = _interp_dx(pairs_mono, 60.0)
    return {"D10": D10, "D30": D30, "D60": D60}

def coefficients(D10: float, D30: float, D60: float) -> Dict[str, float]:
    def _safe(v): 
        return (not (isinstance(v, float) and math.isnan(v))) and v is not None
    if not _safe(D10) or D10 <= 0 or not _safe(D60) or D60 <= 0:
        Cu = float("nan")
    else:
        Cu = D60 / D10
    if not _safe(D10) or not _safe(D30) or not _safe(D60) or D10 <= 0 or D60 <= 0:
        Cc = float("nan")
    else:
        Cc = (D30 ** 2.0) / (D10 * D60)
    return {"Cu": Cu, "Cc": Cc}

def psd_summary(sizes_mm=None, passing_pct=None, pairs=None) -> Dict[str, float]:
    dvals = compute_d_values(sizes_mm=sizes_mm, passing_pct=passing_pct, pairs=pairs)
    coefs = coefficients(dvals["D10"], dvals["D30"], dvals["D60"])
    return {**dvals, **coefs}
