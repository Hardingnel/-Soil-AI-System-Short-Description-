
from __future__ import annotations
import json
import numpy as np
import gradio as gr

from soil_backend.loader import load_everything
from soil_backend.features import vectorize, load_feature_list, presentable_report
from engine.psd import psd_summary
from engine.plots import gradation_plot

DEFAULT_MANIFEST = "/content/drive/MyDrive/soil_ai/models/current.json"

def try_load_backend(manifest_path: str):
    info = "Backend not loaded."
    feature_list = []
    cbr_model = None
    report = {}
    try:
        m, mods, info, report = load_everything(manifest_path)
        cbr_model = mods.get("cbr_model")
        feature_list = mods.get("feature_list") or []
    except Exception as e:
        info = f"Backend load error: {e}"
    return info, feature_list, cbr_model, report

backend_info, FEATURE_LIST, CBR_MODEL, VERIFY = try_load_backend(DEFAULT_MANIFEST)

def _parse_numbers(line: str):
    if not line.strip():
        return []
    parts = [p.strip() for p in line.replace(";", ",").split(",")]
    out = []
    for p in parts:
        if not p: 
            continue
        try:
            out.append(float(p))
        except:
            for q in p.split():
                if q.strip():
                    out.append(float(q))
    return out

def psd_compute_and_plot(sizes_line: str, passing_line: str):
    sizes = _parse_numbers(sizes_line)
    passing = _parse_numbers(passing_line)
    if len(sizes) != len(passing) or len(sizes) < 2:
        return "❗ Enter the same count for sizes & %passing (min 2).", None
    s = psd_summary(sizes_mm=sizes, passing_pct=passing)
    fig = gradation_plot(
        sizes_mm=sizes, passing_pct=passing,
        dvals={"D10": s["D10"], "D30": s["D30"], "D60": s["D60"]},
        coefs={"Cu": s["Cu"], "Cc": s["Cc"]},
    )
    fmt = lambda v: "NaN" if (v is None or (isinstance(v, float) and (np.isnan(v) or np.isinf(v)))) else f"{float(v):.4g}"
    txt = "\\n".join([
        f"D10 (mm): {fmt(s['D10'])}",
        f"D30 (mm): {fmt(s['D30'])}",
        f"D60 (mm): {fmt(s['D60'])}",
        f"Cu: {fmt(s['Cu'])}",
        f"Cc: {fmt(s['Cc'])}",
    ])
    return txt, fig

def cbr_predict(json_payload: str):
    if not FEATURE_LIST:
        return "⚠️ feature_list.json not found/loaded. Check your manifest.", None, None
    try:
        payload = json.loads(json_payload) if json_payload.strip() else {}
    except Exception as e:
        return f"❗ Invalid JSON: {e}", None, None
    try:
        X = vectorize(payload, FEATURE_LIST)
        rep = presentable_report(payload, FEATURE_LIST)
    except Exception as e:
        return f"❗ Vectorize error: {e}", None, None
    if CBR_MODEL is None:
        return "ℹ️ CBR model not loaded — prediction unavailable yet.", rep, X.tolist()
    try:
        y = CBR_MODEL.predict(X)
        return f"Predicted Adopted_CBR_pct: {float(y[0]):.3f}", rep, X.tolist()
    except Exception as e:
        return f"❗ Model predict error: {e}", rep, X.tolist()

with gr.Blocks(title="Soil AI — Phase 2 Skeleton") as demo:
    gr.Markdown("# Soil AI — Phase 2\\nMinimal skeleton with a working PSD tab")
    gr.Markdown(f"**Backend:** {backend_info}")

    with gr.Tab("PSD (Sieve)"):
        gr.Markdown("Example:\\n**Sizes**: `19, 9.5, 4.75, 2, 0.425, 0.075`\\n**% Passing**: `100, 95, 80, 55, 20, 5`")
        sizes_in = gr.Textbox(label="Particle sizes (mm)")
        pass_in  = gr.Textbox(label="% Passing (0–100)")
        run_btn  = gr.Button("Compute & Plot")
        out_txt  = gr.Textbox(label="Indices (D10, D30, D60, Cu, Cc)")
        out_fig  = gr.Plot(label="Gradation curve")
        run_btn.click(psd_compute_and_plot, [sizes_in, pass_in], [out_txt, out_fig])

    with gr.Tab("CBR Prediction"):
        gr.Markdown("Paste JSON with your lab values (keys match the feature list; LL/PL/PI/F200/Dx/OMC/MDD aliases allowed).")
        payload_in = gr.Textbox(
            label="Input JSON", lines=8,
            placeholder='{"LL": 45, "PL": 20, "F200": 55, "D10": 0.2, "D30": 0.5, "D60": 0.9, "OMC": 12.5, "MDD": 1.98}'
        )
        pred_btn = gr.Button("Predict CBR")
        pred_out = gr.Textbox(label="Prediction")
        rep_out  = gr.JSON(label="Vectorization report")
        x_out    = gr.JSON(label="Feature vector (1 x n)")
        pred_btn.click(cbr_predict, [payload_in], [pred_out, rep_out, x_out])

    with gr.Tab("Classifier (stub)"):
        gr.Markdown("Rule-based USCS/A-line will be added in 2.7.")

    with gr.Tab("Summary / Export"):
        gr.Markdown("Coming in 2.8.")

if __name__ == "__main__":
    demo.launch()
