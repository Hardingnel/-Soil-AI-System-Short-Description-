
# engine/plots.py
from __future__ import annotations
from typing import Iterable, Tuple, List, Dict, Any, Optional
import math
import plotly.graph_objects as go

def _is_num(x: Any) -> bool:
    try: float(x); return True
    except: return False

def _pairs(sizes_mm=None, passing_pct=None, pairs=None):
    if pairs is not None:
        data = [(float(s), float(p)) for (s, p) in pairs if _is_num(s) and _is_num(p)]
    elif sizes_mm is not None and passing_pct is not None:
        data = [(float(s), float(p)) for s, p in zip(sizes_mm, passing_pct) if _is_num(s) and _is_num(p)]
    else:
        raise ValueError("Provide sizes_mm+passing_pct or pairs")
    data = [(s,p) for (s,p) in data if s>0 and 0<=p<=100]
    if not data: raise ValueError("No valid PSD data")
    data.sort(key=lambda t: t[0], reverse=True)
    fixed=[]; last=-math.inf
    for s,p in data:
        if p<last: p=last
        last=p; fixed.append((s,p))
    return fixed

def gradation_plot(sizes_mm=None, passing_pct=None, pairs=None,
                   dvals: Optional[Dict[str,float]]=None,
                   coefs: Optional[Dict[str,float]]=None,
                   title="Particle Size Distribution"):
    pts = _pairs(sizes_mm, passing_pct, pairs)
    x=[s for s,_ in pts]; y=[p for _,p in pts]
    fig=go.Figure()
    fig.add_trace(go.Scatter(x=x,y=y,mode="lines+markers",name="% Passing"))
    if dvals:
        for key,pct in (("D10",10),("D30",30),("D60",60)):
            v=dvals.get(key)
            if isinstance(v,(int,float)) and v>0 and not math.isnan(v):
                fig.add_trace(go.Scatter(x=[v,v],y=[0,100],
                                         mode="lines",name=f"{key}={v:.3g}mm",
                                         line=dict(dash="dot")))
    fig.update_layout(
        title=title, xaxis=dict(title="Particle Size (mm)", type="log", autorange="reversed"),
        yaxis=dict(title="% Passing", range=[0,100]),
        template="plotly_white"
    )
    return fig
