# app.py — Phase 2.5 (Results panel + export)
from __future__ import annotations
import json, csv, os, time, math
from pathlib import Path
import numpy as np
import gradio as gr

# our modules
from soil_backend.loader import load_everything
from soil_backend.features import vectorize, presentable_report
from engine.psd import psd_summary
from engine.plots import gradation_plot

# ---------- Config ----------
DEFAULT_MANIFEST = "/content/drive/MyDrive/soil_ai/models/current.json"
ARTIFACTS_DIR = Path("./artifacts"); ARTIFACTS_DIR.mkdir(parents=True, exist_ok=True)

# ---------- Backend load (safe if missing) ----------
def try_load_backend(manifest_path: str):
    info = "Backend not loaded."
    feature_list = []; cbr_model = None; report = {}
    try:
        m, mods, info, report = load_everything(manifest_path)
        cbr_model  = mods.get("cbr_model")
        feature_list = mods.get("feature_list") or []
    except Exception as e:
        info = f"Backend load error: {e}"
    return info, feature_list, cbr_model, report

backend_info, FEATURE_LIST, CBR_MODEL, VERIFY = try_load_backend(DEFAULT_MANIFEST)

# ---------- Helpers ----------
def _nums(line: str):
    if not line or not line.strip(): return []
    out=[]
    for token in line.replace(";", ",").split(","):
        token=token.strip()
        if not token: continue
        try: out.append(float(token))
        except:
            for q in token.split():
                q=q.strip()
                if q: out.append(float(q))
    return out

def _fmt(v):
    try:
        v = float(v)
        if np.isnan(v) or np.isinf(v): return "N/A"
        return f"{v:.4g}"
    except:
        return "N/A"

def _nice_indices_text(s, notes=None):
    lines = [
        f"D10 (mm): {_fmt(s.get('D10'))}",
        f"D30 (mm): {_fmt(s.get('D30'))}",
        f"D60 (mm): {_fmt(s.get('D60'))}",
        f"Cu: {_fmt(s.get('Cu'))}",
        f"Cc: {_fmt(s.get('Cc'))}",
    ]
    if notes:
        lines.append("\nNotes:")
        for n in notes:
            lines.append(f"• {n}")
    return "\n".join(lines)

def _save_psd_summary_csv(sizes, passing, summary) -> str:
    ts = time.strftime("%Y%m%d_%H%M%S")
    out_path = ARTIFACTS_DIR / f"psd_summary_{ts}.csv"
    with out_path.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["# PSD summary generated", time.ctime()])
        w.writerow([])
        w.writerow(["Index", "Value"])
        for k in ("D10","D30","D60","Cu","Cc"):
            w.writerow([k, _fmt(summary.get(k))])
        w.writerow([])
        w.writerow(["size_mm", "percent_passing"])
        for s, p in zip(sizes, passing):
            w.writerow([s, p])
    return str(out_path)

def _percent_at_size(sizes, passing, target_mm):
    pairs = [(float(s), float(p)) for s,p in zip(sizes, passing) if s>0 and 0<=p<=100]
    if len(pairs) < 2: return float("nan")
    pairs.sort(key=lambda t: t[0], reverse=True)
    fixed=[]; last=float("inf")
    for s,p in pairs:
        if p > last: p = last
        last = p; fixed.append((s,p))
    xt = math.log10(target_mm)
    for (s1,y1),(s2,y2) in zip(fixed[:-1], fixed[1:]):
        if (s1 >= target_mm >= s2) or (s2 >= target_mm >= s1):
            x1,x2 = math.log10(s1), math.log10(s2)
            if x2 == x1: return y1
            y = y1 + (y2 - y1) * (xt - x1) / (x2 - x1)
            return float(y)
    return float("nan")

# ---------- PSD (manual) ----------
def psd_compute_and_plot(sizes_line: str, passing_line: str, psd_state: dict):
    sizes = _nums(sizes_line); yraw = _nums(passing_line)
    if len(sizes) != len(yraw) or len(sizes) < 2:
        return "❗ Enter the same count for sizes & values (min 2).", None, None, gr.update(value=psd_state)

    pairs = sorted(zip(sizes, yraw), key=lambda t: t[0], reverse=True)
    sizes  = [s for s,_ in pairs]; values = [p for _,p in pairs]
    notes = []

    # If user gave %retained (sum≈100), convert to %passing
    if 90 <= sum(values) <= 110:
        passing = list(100 - np.cumsum(values))
        notes.append("Converted % retained → % passing.")
    else:
        passing = values[:]

    # If passing increases towards finer sieves, reverse
    if len(passing) >= 2 and passing[0] < passing[-1]:
        sizes   = list(reversed(sizes))
        passing = list(reversed(passing))
        notes.append("Reversed to enforce decreasing % passing fine-ward.")

    passing = [max(0.0, min(100.0, float(p))) for p in passing]

    try:
        s = psd_summary(sizes_mm=sizes, passing_pct=passing)
    except Exception as e:
        return f"❗ PSD error: {e}", None, None, gr.update(value=psd_state)

    pmin, pmax = float(min(passing)), float(max(passing))
    for key, pct in (("D10",10.0), ("D30",30.0), ("D60",60.0)):
        v = s.get(key)
        if isinstance(v, float) and (np.isnan(v) or np.isinf(v)):
            if pmax < pct: notes.append(f"{key} undefined: curve never reaches {pct}% (max={pmax:.1f}%).")
            elif pmin > pct: notes.append(f"{key} undefined: all points already above {pct}% (min={pmin:.1f}%).")
            else: notes.append(f"{key} undefined near {pct}% (add intermediate sieve).")

    fig = gradation_plot(sizes_mm=sizes, passing_pct=passing,
                         dvals={"D10": s["D10"], "D30": s["D30"], "D60": s["D60"]},
                         coefs={"Cu": s["Cu"], "Cc": s["Cc"]})
    csv_path = _save_psd_summary_csv(sizes, passing, s)
    new_state = {"sizes": sizes, "passing": passing, "summary": s}
    return _nice_indices_text(s, notes), fig, csv_path, new_state

# ---------- PSD (CSV upload) ----------
def _read_csv_pairs(file_path: str):
    size_keys = {"size_mm","size","particle_size_mm","mm"}
    pass_keys = {"passing_pct","percent_passing","passing","%passing","pct","%"}
    sizes, passing = [], []
    with open(file_path, "r", encoding="utf-8") as f:
        rows = list(csv.reader(f))
    if not rows: raise ValueError("CSV file is empty.")
    # try header
    headers = [h.strip().lower() for h in rows[0]]
    def idx(keys):
        for k in keys:
            if k in headers: return headers.index(k)
        return None
    i_sz = idx(size_keys); i_ps = idx(pass_keys)
    start = 1 if (i_sz is not None and i_ps is not None) else 0
    for r in rows[start:]:
        if len(r) < 2: continue
        try:
            s = float(r[i_sz] if start else r[0])
            p = float(r[i_ps] if start else r[1])
            if s>0 and 0<=p<=100:
                sizes.append(s); passing.append(p)
        except: continue
    if len(sizes) < 2: raise ValueError("Need at least two (size, %passing) rows.")
    return sizes, passing

def psd_from_csv(file_obj, psd_state: dict):
    if file_obj is None:
        return "❗ Please upload a CSV first.", None, None, gr.update(value=psd_state)
    try:
        sizes, passing = _read_csv_pairs(file_obj.name)
    except Exception as e:
        return f"❗ CSV parse error: {e}", None, None, gr.update(value=psd_state)

    pairs = sorted(zip(sizes, passing), key=lambda t: t[0], reverse=True)
    sizes  = [s for s,_ in pairs]; passing= [p for _,p in pairs]
    if len(passing) >= 2 and passing[0] < passing[-1]:
        sizes, passing = list(reversed(sizes)), list(reversed(passing))

    try:
        s = psd_summary(sizes_mm=sizes, passing_pct=passing)
    except Exception as e:
        return f"❗ PSD error: {e}", None, None, gr.update(value=psd_state)

    fig = gradation_plot(sizes_mm=sizes, passing_pct=passing,
                         dvals={"D10": s["D10"], "D30": s["D30"], "D60": s["D60"]},
                         coefs={"Cu": s["Cu"], "Cc": s["Cc"]})
    csv_path = _save_psd_summary_csv(sizes, passing, s)
    new_state = {"sizes": sizes, "passing": passing, "summary": s}
    return _nice_indices_text(s), fig, csv_path, new_state

# ---------- RESULTS (combine everything + optional CBR prediction) ----------
def build_results(LL, PL, OMC, MDD, Gs, Cc, Cv, phi_deg, cohesion_kpa, psd_state):
    if not isinstance(psd_state, dict) or not psd_state.get("sizes"):
        return "❗ Compute PSD first (manual or CSV).", None
    # parse floats safely
    def f(x):
        try:
            if x in (None, ""): return float("nan")
            return float(x)
        except: return float("nan")

    LL, PL, OMC, MDD = f(LL), f(PL), f(OMC), f(MDD)
    Gs, Cc, Cv = f(Gs), f(Cc), f(Cv)
    phi_deg, cohesion_kpa = f(phi_deg), f(cohesion_kpa)
    PI = (LL - PL) if (not np.isnan(LL) and not np.isnan(PL)) else float("nan")

    sizes = psd_state["sizes"]; passing = psd_state["passing"]; s = psd_state["summary"]
    # F200 (% passing at 0.075 mm)
    F200 = _percent_at_size(sizes, passing, 0.075)

    results = {
        "D10_mm": s.get("D10"), "D30_mm": s.get("D30"), "D60_mm": s.get("D60"),
        "Cu": s.get("Cu"), "Cc": s.get("Cc"),
        "LL": LL, "PL": PL, "PI": PI,
        "F200_pct": F200,
        "OMC_pct": OMC, "MDD_g_per_cm3": MDD,
        "Gs": Gs, "Cc_cons": Cc, "Cv_cm2_per_s": Cv,
        "phi_deg": phi_deg, "cohesion_kPa": cohesion_kpa,
    }

    # Optional CBR prediction
    cbr_pred = None
    if FEATURE_LIST:
        payload = {"LL": LL, "PL": PL, "PI": PI, "F200": F200,
                   "D10": s.get("D10"), "D30": s.get("D30"), "D60": s.get("D60"),
                   "OMC": OMC, "MDD": MDD}
        try:
            X = vectorize(payload, FEATURE_LIST)
            if CBR_MODEL is not None:
                cbr_pred = float(CBR_MODEL.predict(X)[0])
        except Exception:
            cbr_pred = None
    if cbr_pred is not None:
        results["Adopted_CBR_pct_pred"] = cbr_pred

    # write one combined CSV
    ts = time.strftime("%Y%m%d_%H%M%S")
    out_path = ARTIFACTS_DIR / f"soil_results_{ts}.csv"
    with out_path.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["# Soil AI results", time.ctime()])
        w.writerow([])
        w.writerow(["Field","Value"])
        for k,v in results.items():
            w.writerow([k, v])
        w.writerow([])
        w.writerow(["size_mm","percent_passing"])
        for a,b in zip(sizes, passing):
            w.writerow([a,b])

    return results, str(out_path)

# ---------- UI ----------
with gr.Blocks(title="Soil AI — Phase 2.5") as demo:
    state_psd = gr.State(value={})
    gr.Markdown("# Soil AI — Phase 2.5\nPSD + Results export\n")
    gr.Markdown(f"**Backend:** {backend_info}")

    with gr.Tab("PSD (Sieve)"):
        gr.Markdown("### Manual input\nExample:\n**Sizes**: `19, 9.5, 4.75, 2, 0.425, 0.075`\n**% Passing**: `100, 95, 80, 55, 20, 5`")
        with gr.Row():
            sizes_in = gr.Textbox(label="Particle sizes (mm)", value="19, 9.5, 4.75, 2, 0.425, 0.075")
            pass_in  = gr.Textbox(label="% Passing (0–100)", value="100, 95, 80, 55, 20, 5")
        run_btn  = gr.Button("Compute & Plot (manual)")
        out_txt  = gr.Textbox(label="Indices", interactive=False, lines=7)
        out_fig  = gr.Plot(label="Gradation curve")
        out_file = gr.File(label="Download PSD summary CSV", interactive=False)
        run_btn.click(psd_compute_and_plot, [sizes_in, pass_in, state_psd],
                      [out_txt, out_fig, out_file, state_psd])

        gr.Markdown("---\n### CSV upload\nAccepted: header `size_mm, passing_pct` (synonyms OK) **or** two columns.")
        file_in  = gr.File(label="Upload CSV", file_types=[".csv"])
        run_csv  = gr.Button("Compute & Plot (from CSV)")
        out_txt2 = gr.Textbox(label="Indices (CSV)", interactive=False, lines=7)
        out_fig2 = gr.Plot(label="Gradation curve (CSV)")
        out_file2= gr.File(label="Download PSD summary CSV (upload)", interactive=False)
        run_csv.click(psd_from_csv, [file_in, state_psd],
                      [out_txt2, out_fig2, out_file2, state_psd])

    with gr.Tab("Results"):
        gr.Markdown("Enter properties. Then **Build Results** (requires PSD computed above).")
        with gr.Row():
            LL = gr.Number(label="LL")
            PL = gr.Number(label="PL")
            OMC = gr.Number(label="OMC (%)")
            MDD = gr.Number(label="MDD (g/cm³)")
        with gr.Row():
            Gs = gr.Number(label="Specific Gravity (Gs)")
            Cc = gr.Number(label="Compression Index (Cc)")
            Cv = gr.Number(label="Coefficient of Consolidation (Cv, cm²/s)")
        with gr.Row():
            phi = gr.Number(label="Friction angle φ (deg)")
            coh = gr.Number(label="Cohesion c (kPa)")
        build_btn = gr.Button("Build Results & Export")
        res_json  = gr.JSON(label="Results (all)")
        res_file  = gr.File(label="Download full results CSV", interactive=False)
        build_btn.click(build_results,
                        [LL, PL, OMC, MDD, Gs, Cc, Cv, phi, coh, state_psd],
                        [res_json, res_file])

    with gr.Tab("CBR Prediction"):
        gr.Markdown("Paste JSON with your lab values. (Independent of the Results tab.)")
        payload_in = gr.Textbox(
            label="Input JSON", lines=8,
            placeholder='{"LL":45,"PL":20,"F200":55,"D10":0.2,"D30":0.5,"D60":0.9,"OMC":12.5,"MDD":1.98}'
        )
        pred_btn = gr.Button("Predict CBR")
        pred_out = gr.Textbox(label="Prediction")
        rep_out  = gr.JSON(label="Vectorization report")
        x_out    = gr.JSON(label="Feature vector (1 x n)")
        def cbr_predict(json_payload: str):
            if not FEATURE_LIST:
                return "⚠️ feature_list.json not loaded. Check your manifest.", None, None
            try:
                payload = json.loads(json_payload) if json_payload.strip() else {}
            except Exception as e:
                return f"❗ Invalid JSON: {e}", None, None
            try:
                X = vectorize(payload, FEATURE_LIST)
                rep = presentable_report(payload, FEATURE_LIST)
            except Exception as e:
                return f"❗ Vectorize error: {e}", None, None
            if CBR_MODEL is None:
                return "ℹ️ CBR model not loaded.", rep, X.tolist()
            try:
                y = CBR_MODEL.predict(X)
                return f"Predicted Adopted_CBR_pct: {float(y[0]):.3f}", rep, X.tolist()
            except Exception as e:
                return f"❗ Model predict error: {e}", rep, X.tolist()
        pred_btn.click(cbr_predict, [payload_in], [pred_out, rep_out, x_out])

if __name__ == "__main__":
    demo.queue().launch(inline=True, debug=True)
