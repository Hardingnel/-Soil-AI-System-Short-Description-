import os, json, joblib, numpy as np, pandas as pd
from pathlib import Path

def project_root() -> Path:
    # 1) optional override for notebooks
    env = os.getenv("SOIL_AI_BASE")
    if env:
        return Path(env).resolve()
    # 2) scripts (Spaces / local) — __file__ exists
    try:
        return Path(__file__).resolve().parents[1]
    except NameError:
        # 3) notebooks: walk upward to find a folder with models/
        cwd = Path.cwd()
        for cand in [cwd, *cwd.parents]:
            if (cand / "models").exists():
                return cand
        return cwd

BASE = project_root()
MODEL_DIR = BASE / "models"

def _read_latest_path() -> Path:
    latest = MODEL_DIR / "latest.txt"
    if not latest.exists():
        raise FileNotFoundError(f"{latest} not found")
    txt = latest.read_text().strip()
    p = Path(txt)
    if not p.is_absolute():
        p = MODEL_DIR / p
    if not p.exists():
        raise FileNotFoundError(f"Model file not found: {p}")
    return p

def feature_order():
    fp = MODEL_DIR / "feature_list.json"
    if fp.exists():
        return json.loads(fp.read_text())
    # fallback if feature_list.json missing
    return ["MDD","OMC","Gs","LL","PL","PI","Fines_%",
            "D10_mm","D30_mm","D60_mm","Cu","Cc","Cv","Soaked"]

def _align_df(X: pd.DataFrame, cols):
    X = pd.DataFrame(X).copy()
    # make sure all columns exist and in correct order
    for c in cols:
        if c not in X.columns:
            X[c] = np.nan
    X = X[cols]
    # coerce numeric (except Soaked)
    for c in X.columns:
        if c.lower() == "soaked":
            X[c] = X[c].fillna("No")
        else:
            X[c] = pd.to_numeric(X[c], errors="coerce")
            if X[c].isna().any():
                med = X[c].median(skipna=True)
                X[c] = X[c].fillna(med)
    return X

def load_cbr_model():
    model_path = _read_latest_path()
    model = joblib.load(model_path)
    feats = feature_order()
    return model, feats

def predict_cbr(X_df: pd.DataFrame) -> np.ndarray:
    model, cols = load_cbr_model()
    X = _align_df(X_df, cols)
    y = model.predict(X)
    return np.asarray(y, dtype=float)

__all__ = ["project_root", "feature_order", "predict_cbr"]
