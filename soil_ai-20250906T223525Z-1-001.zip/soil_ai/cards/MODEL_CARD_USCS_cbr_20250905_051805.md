# Soil AI — MODEL CARD (USCS) — cbr_20250905_051805

## Overview
- **Type:** Rule-based (USCS) — no ML training required
- **Inputs (features):** LL, PL, PI, F200, Cu, Cc
- **Data artifact:** `data/processed/soil_with_uscs.csv`
- **Diagnostics:** `plots/uscs_confmat_cbr_20250905_051805.png`

## Data & Coverage
- Rows in canonical file: **20**
- Rows with USCS populated: **0**

## Acceptance Gate (if ground-truth provided)
- **Target:** Accuracy ≥ 0.82, Macro-F1 ≥ 0.78
- **Result:** ground-truth not provided → showing coverage/class counts only.

## Assumptions & Limitations
- Requires **LL, PL, % passing #200 (F200)**. For clean sands, **Cu & Cc** decide SW vs SP.
- If F200 is missing, classification is **None**.
- Units assumed: % for LL/PL/F200; sieve sizes in mm (No.200 = 0.075 mm).

## Environment
- python: 3.12.11
- numpy: 2.0.2
- pandas: 2.2.2
- sklearn: 1.6.1
- matplotlib: 3.10.0
- joblib: 1.5.2
- platform: Linux 6.1.123+