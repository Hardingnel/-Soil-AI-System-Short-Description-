
from __future__ import annotations
from typing import Dict, List, Tuple, Any
from pathlib import Path
import json, math, numpy as np

# ---- Aliases so different spellings still map to canonical feature keys ----
ALIAS_MAP: Dict[str, str] = {
    "liquid_limit": "LL", "ll": "LL",
    "plastic_limit": "PL", "pl": "PL",
    "plasticity_index": "PI", "pi": "PI",
    "f200": "F200", "p200": "F200", "percent_passing_0.075": "F200",
    "%passing_0.075": "F200", "percent_fines": "F200", "fines_pct": "F200",
    "d10": "D10", "d30": "D30", "d60": "D60",
    "omc": "OMC", "optimum_moisture_content": "OMC",
    "mdd": "MDD", "maximum_dry_density": "MDD",
    "cu": "Cu", "cc": "Cc",
}

PERCENT_KEYS = {"F200", "OMC"}                 # 0–100
POSITIVE_KEYS = {"D10", "D30", "D60", "MDD", "Cu"}   # > 0
NONNEG_KEYS  = {"LL", "PL", "PI", "Cc"}              # >= 0

def load_feature_list(path: str | Path) -> List[str]:
    p = Path(path).expanduser().resolve()
    if not p.exists():
        raise FileNotFoundError(f"Feature list not found: {p}")
    data = json.loads(p.read_text(encoding="utf-8"))
    if isinstance(data, dict) and "features" in data:
        feats = list(map(str, data["features"]))
    elif isinstance(data, list):
        feats = list(map(str, data))
    else:
        raise ValueError(f"Unrecognized feature list format at {p}")
    seen=set(); ordered=[]
    for k in feats:
        if k not in seen:
            ordered.append(k); seen.add(k)
    return ordered

def _to_key(k: str) -> str:
    if not isinstance(k, str): return k
    k_trim = k.strip()
    if k_trim in ALIAS_MAP.values(): return k_trim
    return ALIAS_MAP.get(k_trim.lower(), k_trim)

def _to_float(x: Any) -> float:
    if x is None: return np.nan
    if isinstance(x, (int,float)) and not isinstance(x, bool):
        return float(x)
    if isinstance(x, str):
        s = x.strip().replace(",", "")
        if s == "" or s.lower() in {"nan", "none", "null"}: return np.nan
        try: return float(s)
        except: return np.nan
    try: return float(x)
    except: return np.nan

def normalize_payload(payload: Dict[str, Any]) -> Dict[str, float]:
    norm: Dict[str, float] = {}
    for raw_k, raw_v in (payload or {}).items():
        norm[_to_key(raw_k)] = _to_float(raw_v)
    # derive PI if missing and LL/PL present
    pi = norm.get("PI", np.nan)
    if "PI" not in norm or (isinstance(pi, float) and math.isnan(pi)):
        ll = norm.get("LL", np.nan); pl = norm.get("PL", np.nan)
        if not math.isnan(ll) and not math.isnan(pl):
            norm["PI"] = float(ll) - float(pl)
    return norm

def validate_payload(payload: Dict[str, Any]) -> Tuple[Dict[str, float], List[str]]:
    norm = normalize_payload(payload)
    warnings: List[str] = []
    # clip percentages
    for k in PERCENT_KEYS:
        if k in norm:
            v = norm[k]
            if not math.isnan(v) and (v < 0 or v > 100):
                warnings.append(f"{k}={v} outside 0–100; clipped")
                norm[k] = max(0.0, min(100.0, v))
    # positive-only
    for k in POSITIVE_KEYS:
        if k in norm:
            v = norm[k]
            if not math.isnan(v) and v <= 0:
                warnings.append(f"{k}={v} should be > 0")
    # non-negative
    for k in NONNEG_KEYS:
        if k in norm:
            v = norm[k]
            if not math.isnan(v) and v < 0:
                warnings.append(f"{k}={v} should be ≥ 0")
    # Atterberg consistency
    ll, pl, pi = norm.get("LL", np.nan), norm.get("PL", np.nan), norm.get("PI", np.nan)
    if not math.isnan(ll) and not math.isnan(pl) and ll < pl:
        warnings.append(f"LL ({ll}) < PL ({pl}); PI may be invalid")
    if not math.isnan(pi) and pi < 0:
        warnings.append(f"PI ({pi}) negative; check LL/PL")
    return norm, warnings

def vectorize(payload: Dict[str, Any], feature_list: List[str]) -> np.ndarray:
    if not feature_list:
        raise ValueError("Empty feature_list — cannot vectorize")
    norm, _ = validate_payload(payload)
    row = [_to_float(norm.get(f, np.nan)) for f in feature_list]
    return np.array([row], dtype=float)

def presentable_report(payload: Dict[str, Any], feature_list: List[str]) -> Dict[str, Any]:
    norm, warnings = validate_payload(payload)
    ordered_inputs = [{"name": f, "value": _to_float(norm.get(f, np.nan))} for f in feature_list]
    missing = [f for f in feature_list if math.isnan(_to_float(norm.get(f, np.nan)))]
    return {"ordered_inputs": ordered_inputs, "missing": missing, "warnings": warnings}
