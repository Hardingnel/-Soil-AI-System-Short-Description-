# Soil AI Snapshot — cbr_20250905_051805

- Created: 20250905_054120
- Contains zipped artifacts for models/logs/plots/cards + data/processed
- Integrity checks in MANIFEST.csv (sha256)
- Registry files: latest.txt, feature_list.json
