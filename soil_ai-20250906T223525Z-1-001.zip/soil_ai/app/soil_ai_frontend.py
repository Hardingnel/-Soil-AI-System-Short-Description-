# soil_ai_frontend.py
# Frontend with dynamic PSD & CBR tables, CSV alternatives,
# per-tab CSV downloads, and Summary export.

from __future__ import annotations
import math
from pathlib import Path
import numpy as np
import pandas as pd
import plotly.graph_objects as go
import gradio as gr

# Temp output folder for CSVs during a session
OUT_DIR = Path("/tmp/soil_ai")
OUT_DIR.mkdir(parents=True, exist_ok=True)

# ---------- Utilities ----------
def make_empty_df(headers, n_rows, default=None):
    n = int(max(0, n_rows or 0))
    rows = ([default[:] for _ in range(n)] if default is not None
            else [[None for _ in headers] for __ in range(n)])
    return pd.DataFrame(rows, columns=headers)

# ---------- PSD helpers ----------
def _guess_psd_columns(df: pd.DataFrame):
    cols = [str(c).strip().lower() for c in df.columns]
    size_idx = None; pass_idx = None
    for i, c in enumerate(cols):
        if any(k in c for k in ["size", "mm", "sieve", "diam"]):
            if size_idx is None: size_idx = i
        if any(k in c for k in ["pass", "%", "pct"]):
            if pass_idx is None: pass_idx = i
    if size_idx is None: size_idx = 0
    if pass_idx is None: pass_idx = 1 if len(cols) > 1 else 0
    return size_idx, pass_idx

def _interp_Dx(size_mm, pct_pass, target_pct):
    s = pd.to_numeric(pd.Series(size_mm), errors="coerce")
    p = pd.to_numeric(pd.Series(pct_pass), errors="coerce")
    df = pd.DataFrame({"size": s, "pp": p}).dropna()
    if len(df) < 2:
        return np.nan
    df["pp"] = df["pp"].clip(0, 100)
    df = df.sort_values("pp")
    if target_pct < df["pp"].min() or target_pct > df["pp"].max():
        return np.nan
    log_size = np.log10(df["size"].clip(lower=1e-9))
    y = np.interp(target_pct, df["pp"].to_numpy(), log_size.to_numpy())
    return float(10**y)

def compute_psd_from_df(df):
    if df is None or len(df) == 0:
        return go.Figure(), pd.DataFrame(), None
    df = pd.DataFrame(df).copy()
    if len(df.columns) >= 2:
        i_size, i_pp = _guess_psd_columns(df)
        df = df.iloc[:, [i_size, i_pp]]
    else:
        return go.Figure(), pd.DataFrame(), None
    df.columns = ["size_mm", "pct_passing"]
    df = df.replace([np.inf, -np.inf], np.nan).dropna()
    if df.empty:
        return go.Figure(), pd.DataFrame(), None
    df = df.sort_values("size_mm", ascending=False)

    D10 = _interp_Dx(df["size_mm"], df["pct_passing"], 10)
    D30 = _interp_Dx(df["size_mm"], df["pct_passing"], 30)
    D60 = _interp_Dx(df["size_mm"], df["pct_passing"], 60)
    Cu  = float(D60/D10) if all(isinstance(v,(int,float)) and v>0 and np.isfinite(v) for v in [D10, D60]) else np.nan
    Cc  = float((D30**2)/(D10*D60)) if all(isinstance(v,(int,float)) and v>0 and np.isfinite(v) for v in [D10, D30, D60]) else np.nan

    grading = None
    try:
        if not np.isnan(D10) and not np.isnan(Cu) and not np.isnan(Cc):
            if D10 >= 2.0:
                grading = "Well-graded gravel (GW?)" if (Cu >= 4 and 1 <= Cc <= 3) else "Poorly graded gravel (GP?)"
            else:
                grading = "Well-graded sand (SW?)" if (Cu >= 6 and 1 <= Cc <= 3) else "Poorly graded sand (SP?)"
    except Exception:
        grading = None

    fig = go.Figure()
    fig.add_trace(go.Scatter(x=df["size_mm"], y=df["pct_passing"],
                             mode="lines+markers", name="PSD",
                             hovertemplate="Size %{x:.3f} mm<br>% Passing %{y:.2f}%<extra></extra>"))
    for lab, Dx, col in [("D10", D10, "#636EFA"), ("D30", D30, "#EF553B"), ("D60", D60, "#00CC96")]:
        if isinstance(Dx,(int,float)) and np.isfinite(Dx):
            fig.add_vline(x=Dx, line_width=1, line_dash="dash", line_color=col)
            fig.add_annotation(x=Dx, y=95, text=f"{lab}={Dx:.3g} mm", showarrow=True, arrowhead=1)
    fig.update_xaxes(type="log", title="Particle size (mm)", showgrid=True)
    fig.update_yaxes(title="% Passing", range=[0,100], showgrid=True)
    fig.update_layout(title="Particle Size Distribution (PSD)", template="plotly_white", height=520)

    metrics = pd.DataFrame([{"D10_mm":D10, "D30_mm":D30, "D60_mm":D60, "Cu":Cu, "Cc_psd":Cc, "Grading_flag":grading}])
    out = OUT_DIR / "psd_summary.csv"
    metrics.assign(n_points=len(df)).to_csv(out, index=False)
    return fig, metrics, str(out)

def compute_psd_flexible(psd_csv, psd_manual_df):
    if psd_csv is not None:
        try:
            df = pd.read_csv(psd_csv.name)
            return compute_psd_from_df(df)
        except Exception:
            pass
    return compute_psd_from_df(psd_manual_df)

# ---------- Plasticity ----------
def compute_plasticity(LL, PL):
    if LL is None or PL is None:
        return go.Figure(), "—", "—", "—"
    try:
        LL = float(LL); PL = float(PL)
    except Exception:
        return go.Figure(), "—", "—", "—"
    PI = max(0.0, LL-PL)
    LL_axis = np.linspace(0, 100, 500)
    A_line  = np.maximum(0, 0.73*(LL_axis-20))
    U_line  = np.maximum(0, 0.9*(LL_axis-8))
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=LL_axis, y=A_line, name="A-Line", mode="lines"))
    fig.add_trace(go.Scatter(x=LL_axis, y=U_line, name="U-Line", mode="lines"))
    fig.add_trace(go.Scatter(x=[LL], y=[PI], mode="markers", marker=dict(size=12),
                             name=f"Sample (LL={LL:.1f}, PI={PI:.1f})",
                             hovertemplate="LL %{x:.1f}<br>PI %{y:.1f}<extra></extra>"))
    fig.update_xaxes(title="Liquid Limit (LL)", range=[0,100])
    fig.update_yaxes(title="Plasticity Index (PI)", range=[0,60])
    fig.update_layout(title="Plasticity Chart (Casagrande)", template="plotly_white", height=520)
    a_val = 0.73*(LL-20)
    uscs  = ("CL" if LL<50 else "CH") if PI>=a_val else ("ML" if LL<50 else "MH")
    if LL >= 41 and PI >= 11: aashto = "A-7 (approx)"
    elif LL < 41 and PI <= 10: aashto = "A-6/A-4 (approx)"
    else: aashto = "A-5/A-7 (approx)"
    return fig, f"{PI:.2f}", uscs, aashto

# ---------- CBR (CSV or manual) ----------
def _extract_pen_load_from_manual(df_manual):
    if df_manual is None or len(df_manual) == 0:
        return None, None
    df = pd.DataFrame(df_manual).iloc[:, :2].copy()
    df.columns = ["penetration_mm", "load_kN"]
    df = df.replace([np.inf, -np.inf], np.nan).dropna()
    if df.empty:
        return None, None
    pen  = pd.to_numeric(df["penetration_mm"], errors="coerce").dropna().to_numpy()
    load = pd.to_numeric(df["load_kN"],       errors="coerce").dropna().to_numpy()
    if len(pen) < 2 or len(load) < 2:
        return None, None
    order = np.argsort(pen)
    return pen[order], load[order]

def compute_cbr_flexible(cbr_csv, manual_df, adopted_direct):
    pen = load = None
    if cbr_csv is not None:
        try:
            df = pd.read_csv(cbr_csv.name)
            cols = {str(c).lower(): c for c in df.columns}
            pen_col  = cols.get("penetration_mm") or cols.get("penetration") or df.columns[0]
            load_col = cols.get("load_kn") or cols.get("load") or df.columns[1]
            pen  = pd.to_numeric(df[pen_col],  errors="coerce").dropna().to_numpy()
            load = pd.to_numeric(df[load_col], errors="coerce").dropna().to_numpy()
            ord_idx = np.argsort(pen); pen = pen[ord_idx]; load = load[ord_idx]
        except Exception:
            pen = load = None
    if pen is None or load is None or len(pen) < 2:
        pen, load = _extract_pen_load_from_manual(manual_df)
    if pen is None or load is None or len(pen) < 2:
        try:
            adopted = None if adopted_direct in (None, "") else float(adopted_direct)
        except Exception:
            adopted = None
        out = None
        if adopted is not None:
            df_out = pd.DataFrame([{"CBR_2p5_%": None, "CBR_5_%": None, "CBR_adopted_%": adopted}])
            out_path = OUT_DIR / "cbr_summary.csv"
            df_out.to_csv(out_path, index=False)
            out = str(out_path)
        return go.Figure(), None, None, adopted, out

    std_2p5, std_5 = 13.24, 19.96
    l2p5 = float(np.interp(2.5, pen, load)); l5 = float(np.interp(5.0, pen, load))
    cbr2 = (l2p5/std_2p5)*100.0; cbr5 = (l5/std_5)*100.0; adopted = max(cbr2, cbr5)

    fig = go.Figure()
    fig.add_trace(go.Scatter(x=pen, y=load, mode="lines+markers", name="Load–Penetration"))
    fig.add_vline(x=2.5, line_dash="dash"); fig.add_vline(x=5.0, line_dash="dash")
    fig.add_annotation(x=2.5, y=l2p5, text=f"CBR2.5 = {cbr2:.1f}%", showarrow=True)
    fig.add_annotation(x=5.0, y=l5,   text=f"CBR5 = {cbr5:.1f}%", showarrow=True)
    fig.update_xaxes(title="Penetration (mm)"); fig.update_yaxes(title="Load (kN)")
    fig.update_layout(title="CBR Load–Penetration", template="plotly_white", height=520)

    df_out = pd.DataFrame([{
        "CBR_2p5_%": cbr2, "CBR_5_%": cbr5, "CBR_adopted_%": adopted,
        "n_points": len(pen)
    }])
    out_path = OUT_DIR / "cbr_summary.csv"
    df_out.to_csv(out_path, index=False)
    return fig, cbr2, cbr5, adopted, str(out_path)

# ---------- Shear helpers ----------
def fit_shear(sigma_list, tau_list):
    try:
        s = pd.to_numeric(pd.DataFrame(sigma_list).iloc[:,0], errors="coerce")
    except Exception:
        s = pd.Series(dtype=float)
    try:
        t = pd.to_numeric(pd.DataFrame(tau_list).iloc[:,0], errors="coerce")
    except Exception:
        t = pd.Series(dtype=float)
    df = pd.DataFrame({"sigma": s, "tau": t}).dropna()
    if len(df) < 2:
        return None, None, go.Figure()
    X, Y = df["sigma"].values, df["tau"].values
    A = np.vstack([X, np.ones_like(X)]).T
    m, c = np.linalg.lstsq(A, Y, rcond=None)[0]
    phi = math.degrees(math.atan(m))
    xline = np.linspace(0, max(1, X.max()*1.1), 50)
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=X, y=Y, mode="markers", name="(σ,τ) points"))
    fig.add_trace(go.Scatter(x=xline, y=c+m*xline, mode="lines", name="Failure envelope"))
    fig.update_layout(template="plotly_white", title="Mohr–Coulomb Envelope", height=520,
                      xaxis_title="σ (kPa)", yaxis_title="τ (kPa)")
    return float(phi), float(c), fig

# ---------- Summary builder ----------
def build_summary(adopted_cbr, mdd, omc, gs, cc, cv, phi, coh):
    data = {
        "CBR_adopted_%": [adopted_cbr],
        "MDD_Mg_m3": [mdd],
        "OMC_%": [omc],
        "Gs": [gs],
        "Cc": [cc],
        "Cv_m2_s": [cv],
        "phi_deg": [phi],
        "c_kPa": [coh],
    }
    df = pd.DataFrame(data)
    out_csv = OUT_DIR / "summary.csv"
    df.to_csv(out_csv, index=False)
    return df, str(out_csv)

# ---------- Build the Gradio app ----------
def build_app():
    with gr.Blocks(title="Soil AI — Full Frontend (Dynamic)", theme=gr.themes.Soft()) as app:
        gr.Markdown("## Soil AI — Frontend (Dynamic PSD & CBR Rows + CSV)\n"
                    "Main outputs: CBR, MDD, OMC, Gs, Cc, Cv, φ, c.")

        with gr.Tabs():
            # PSD
            with gr.TabItem("PSD"):
                gr.Markdown("Upload a CSV **or** use the manual table. Choose any number of sieve points.")
                with gr.Row():
                    with gr.Column(scale=5):
                        psd_csv = gr.File(label="PSD CSV (try headers like size_mm, %_passing)", file_types=[".csv"])
                        with gr.Group():
                            psd_rows = gr.Number(label="Manual rows (sieve points)", value=7, precision=0)
                            def _resize_psd(n):
                                df = make_empty_df(["size_mm", "%_passing"], int(max(0, n or 0)))
                                return gr.update(value=df)
                            psd_manual = gr.Dataframe(headers=["size_mm", "%_passing"],
                                                      value=make_empty_df(["size_mm","%_passing"], 7),
                                                      row_count=(7, "dynamic"), col_count=2, type="pandas",
                                                      label="Manual Sieve table")
                            psd_set_rows = gr.Button("Set manual rows")
                            psd_set_rows.click(_resize_psd, [psd_rows], [psd_manual])
                        btn_psd = gr.Button("Plot PSD", variant="primary")
                    with gr.Column(scale=7):
                        psd_plot = gr.Plot(label="PSD curve (semi-log)")
                        dvals_tbl = gr.Dataframe(label="D-values", interactive=False)
                        psd_file = gr.File(label="Download psd_summary.csv", interactive=False)
                def _psd_run(csvf, manual):
                    fig, met, out = compute_psd_flexible(csvf, manual)
                    return fig, met, (out or None)
                btn_psd.click(_psd_run, [psd_csv, psd_manual], [psd_plot, dvals_tbl, psd_file])

            # Plasticity
            with gr.TabItem("Plasticity"):
                with gr.Row():
                    with gr.Column(scale=5):
                        LL = gr.Number(label="Liquid Limit (LL)", value=45)
                        PL = gr.Number(label="Plastic Limit (PL)", value=22)
                        btn_plast = gr.Button("Plot Plasticity", variant="primary")
                    with gr.Column(scale=7):
                        plast_plot = gr.Plot(label="Plasticity chart")
                        with gr.Row():
                            PI_box = gr.Textbox(label="PI (LL−PL)", interactive=False)
                            USCS_box = gr.Textbox(label="USCS", interactive=False)
                            AASHTO_box = gr.Textbox(label="AASHTO (approx)", interactive=False)
                btn_plast.click(compute_plasticity, [LL, PL], [plast_plot, PI_box, USCS_box, AASHTO_box])

            # CBR
            with gr.TabItem("CBR"):
                gr.Markdown("Use **CSV** or the **manual table**. Choose any number of penetration–load pairs.")
                with gr.Row():
                    with gr.Column(scale=5):
                        cbr_csv = gr.File(label="CBR CSV (penetration_mm, load_kN)", file_types=[".csv"])
                        with gr.Group():
                            cbr_rows = gr.Number(label="Manual rows (penetration–load pairs)", value=8, precision=0)
                            def _resize_cbr(n):
                                df = make_empty_df(["penetration_mm", "load_kN"], int(max(0, n or 0)))
                                return gr.update(value=df)
                            manual_cbr = gr.Dataframe(headers=["penetration_mm", "load_kN"],
                                                      value=make_empty_df(["penetration_mm","load_kN"], 8),
                                                      row_count=(8,"dynamic"), col_count=2, type="pandas",
                                                      label="Manual CBR table")
                            cbr_set_rows = gr.Button("Set manual rows")
                            cbr_set_rows.click(_resize_cbr, [cbr_rows], [manual_cbr])
                        adopted_cbr = gr.Number(label="OR enter Adopted CBR directly (%)")
                        btn_cbr = gr.Button("Compute / Plot CBR", variant="primary")
                    with gr.Column(scale=7):
                        cbr_plot = gr.Plot(label="Load–Penetration")
                        with gr.Row():
                            cbr2_box = gr.Textbox(label="CBR @ 2.5 mm (%)", interactive=False)
                            cbr5_box = gr.Textbox(label="CBR @ 5.0 mm (%)", interactive=False)
                            cbr_adopt_box = gr.Textbox(label="Adopted CBR (%)", interactive=False)
                        cbr_file = gr.File(label="Download cbr_summary.csv", interactive=False)

                def _cbrrun(f, manual_df, ad):
                    fig, c2, c5, adopted, out = compute_cbr_flexible(f, manual_df, ad)
                    return fig, ("" if c2 is None else f"{c2:.2f}"), ("" if c5 is None else f"{c5:.2f}"), ("" if adopted is None else f"{adopted:.2f}"), (out or None)
                btn_cbr.click(_cbrrun, [cbr_csv, manual_cbr, adopted_cbr], [cbr_plot, cbr2_box, cbr5_box, cbr_adopt_box, cbr_file])

            # Optional: Compaction / Consolidation / Shear
            with gr.TabItem("Optional: Compaction / Consolidation / Shear"):
                gr.Markdown("Fill any that you have; empty fields are allowed.")
                with gr.Row():
                    with gr.Column():
                        MDD = gr.Number(label="MDD (Mg/m³)")
                        OMC = gr.Number(label="OMC (%)")
                        Gs  = gr.Number(label="Gs (specific gravity)")
                    with gr.Column():
                        Cc_in = gr.Number(label="Cc (Compression Index)")
                        Cv_in = gr.Number(label="Cv (m²/s)")
                    with gr.Column():
                        gr.Markdown("Direct Shear quick (≥2 rows):")
                        shear_sigma = gr.Dataframe(headers=["sigma_kPa"], row_count=3, col_count=1, type="array")
                        shear_tau   = gr.Dataframe(headers=["tau_kPa"],   row_count=3, col_count=1, type="array")
                        btn_shear = gr.Button("Fit Shear Envelope")
                shear_plot = gr.Plot(label="Mohr–Coulomb Envelope")
                phi_box = gr.Textbox(label="φ (deg)", interactive=False)
                c_box   = gr.Textbox(label="c (kPa)", interactive=False)
                def _shearrun(sig, tau):
                    phi, c, fig = fit_shear(sig, tau)
                    return fig, ("" if phi is None else f"{phi:.2f}"), ("" if c is None else f"{c:.2f}")
                btn_shear.click(_shearrun, [shear_sigma, shear_tau], [shear_plot, phi_box, c_box])

            # Summary & Export
            with gr.TabItem("Summary & Export"):
                gr.Markdown("**Main Outputs**")
                summary_cards = gr.Markdown()
                summary_table = gr.Dataframe(label="Summary table", interactive=False)
                summary_file = gr.File(label="Download summary.csv")

                def _collect(adopt_val, mdd, omc, gs, cc, cv, phi_str, c_str):
                    def tofloat(x):
                        try:
                            if x is None or x == "": return None
                            return float(x)
                        except Exception:
                            return None
                    df, path = build_summary(
                        tofloat(adopt_val), tofloat(mdd), tofloat(omc), tofloat(gs),
                        tofloat(cc), tofloat(cv), tofloat(phi_str), tofloat(c_str)
                    )
                    def fmt(v):
                        if v is None or (isinstance(v,float) and (np.isnan(v))): return "—"
                        return f"{v:.2f}" if isinstance(v,(int,float)) else str(v)
                    lines = [
                        "### Main Outputs",
                        f"- **CBR (%)**: {fmt(df['CBR_adopted_%'].iloc[0])}",
                        f"- **MDD (Mg/m³)**: {fmt(df['MDD_Mg_m3'].iloc[0])}",
                        f"- **OMC (%)**: {fmt(df['OMC_%'].iloc[0])}",
                        f"- **Gs**: {fmt(df['Gs'].iloc[0])}",
                        f"- **Cc**: {fmt(df['Cc'].iloc[0])}",
                        f"- **Cv (m²/s)**: {fmt(df['Cv_m2_s'].iloc[0])}",
                        f"- **φ (deg)**: {fmt(df['phi_deg'].iloc[0])}",
                        f"- **c (kPa)**: {fmt(df['c_kPa'].iloc[0])}",
                    ]
                    return "\n".join(lines), df, path

                build_btn = gr.Button("Build Summary & CSV", variant="primary")
                build_btn.click(
                    _collect,
                    inputs=[cbr_adopt_box, MDD, OMC, Gs, Cc_in, Cv_in, phi_box, c_box],
                    outputs=[summary_cards, summary_table, summary_file]
                )

    return app

# Expose an app instance for the runner to import
app = build_app()

if __name__ == "__main__":
    gr.close_all()
    app.launch()
