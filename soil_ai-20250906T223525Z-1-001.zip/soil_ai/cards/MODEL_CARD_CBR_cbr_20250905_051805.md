# Soil AI — MODEL CARD (CBR Regressor) — cbr_20250905_051805

## Overview
- **Type:** Supervised regression (RandomForestRegressor)
- **Target:** `Adopted_CBR_pct`
- **Features (1):** Blows
- **Model artifact:** `models/cbr_regressor_cbr_20250905_051805.pkl`
- **Diagnostics:** `plots/cbr_parity_cbr_20250905_051805.png` (Parity plot)
- **Metrics CSV:** `logs/cbr_metrics_cbr_20250905_051805.csv`

## Evaluation
- **R²:** -3.084
- **RMSE:** 41.428
- **MAE:** 36.000
- **Acceptance gate:** R² ≥ 0.7, RMSE ≤ 6.0 → **REVIEW ⚠️**

## Data & Splits
- Train/test split: stratification not applied (regression). RandomState=42.
- Missing values handled via median imputation in a ColumnTransformer.

## Assumptions & Limitations
- CBR labels must be consistently measured and unit-aligned (%).
- Feature distributions can vary by site; re-train if schema/units change.
- Outliers can inflate RMSE; consider trimming by lab QA where appropriate.

## Environment
- python: 3.12.11
- numpy: 2.0.2
- pandas: 2.2.2
- sklearn: 1.6.1
- matplotlib: 3.10.0
- joblib: 1.5.2
- platform: Linux 6.1.123+