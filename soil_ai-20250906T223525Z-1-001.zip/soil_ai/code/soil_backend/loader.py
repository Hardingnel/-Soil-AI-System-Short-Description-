from __future__ import annotations
import json
from pathlib import Path
from typing import Dict, Any, Optional, Tuple, List
try:
    import joblib
except Exception:
    joblib=None

def _resolve(base: Path, p: Optional[str]):
    if not p: return None
    pth = Path(p)
    return pth if pth.is_absolute() else (base / pth)

def _detect(manifest: Dict[str,Any], base: Path):
    arts = manifest.get("artifacts", {}) or {}
    c_keys = ["cbr_model","cbr_model_path","model","model_path"]
    f_keys = ["feature_list","feature_list_path","features","features_path"]
    cbr = None; feats = None
    for k in c_keys:
        if k in arts:
            cbr = _resolve(base, arts[k]); break
    for k in f_keys:
        if k in arts:
            feats = _resolve(base, arts[k]); break
    if cbr is None:
        for n in ["cbr_model.joblib","cbr_model.pkl","model.joblib","model.pkl"]:
            cand = base / n
            if cand.exists(): cbr=cand; break
    if feats is None:
        for n in ["feature_list.json","features.json"]:
            cand = base / n
            if cand.exists(): feats=cand; break
    return cbr, feats

def load_manifest(p: str | Path):
    p = Path(p).expanduser().resolve()
    if not p.exists(): raise FileNotFoundError(f"Manifest not found: {p}")
    data = json.loads(p.read_text(encoding="utf-8"))
    data["_manifest_path"]=p; data["_base_dir"]=p.parent
    return data

def verify_artifacts(manifest: Dict[str,Any]):
    base = manifest.get("_base_dir")
    cbr, feats = _detect(manifest, base)
    return {
        "manifest_path": str(manifest.get("_manifest_path","")),
        "cbr_model_path": str(cbr) if cbr else None,
        "feature_list_path": str(feats) if feats else None,
        "exists": {
            "cbr_model": bool(cbr and cbr.exists() and cbr.stat().st_size>0),
            "feature_list": bool(feats and feats.exists() and feats.stat().st_size>0),
        },
        "version": manifest.get("version"),
        "trained_on": manifest.get("trained_on")
    }

def load_models(manifest: Dict[str,Any]):
    base = manifest.get("_base_dir")
    cbr, feats = _detect(manifest, base)
    model=None; features=[]
    if cbr and cbr.exists():
        if joblib is None: raise ImportError("joblib required to load model")
        model = joblib.load(cbr)
    if feats and feats.exists():
        j = json.loads(feats.read_text(encoding="utf-8"))
        features = j.get("features", j if isinstance(j,list) else [])
        features = list(map(str, features))
    return {"cbr_model": model, "feature_list": features, "paths": {"cbr_model": str(cbr) if cbr else None, "feature_list": str(feats) if feats else None}}

def model_info(manifest: Dict[str,Any], models: Dict[str,Any]):
    ver = manifest.get("version","v?"); date = manifest.get("trained_on","unknown")
    cm = models.get("cbr_model"); feats = models.get("feature_list",[])
    name = getattr(cm, "__class__", type("?",(),{})).__name__ if cm is not None else "None"
    return f"Backend {ver} • trained: {date} • CBR model: {name} • features: {len(feats)}"

def load_everything(manifest_path: str | Path):
    m = load_manifest(manifest_path)
    rep = verify_artifacts(m)
    mods = load_models(m)
    info = model_info(m, mods)
    return m, mods, info, rep
